<template>
	<nuxt class="page_container" />
</template>
<script>
export default {

}
</script>

<style lang="scss" scoped>
.page_container {
	height: 100%;
}
</style>
