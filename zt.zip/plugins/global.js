import Vue from 'vue';
import global from '~/util/globalUtil.js';

Vue.prototype.$global = global;