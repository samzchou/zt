/* eslint-disable */
import Vue from 'vue';
import ECharts from 'vue-echarts';

// 全部引入
import 'echarts';
import 'echarts-gl';

// 注册组件后即可使用
Vue.component('echart', ECharts);
