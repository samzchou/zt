<template>
    <div>block</div>
</template>

<script>
export default {
    props:{
        positions:{
            type:Object,
            default:{
                top:20,
                height:20
            }
        }
    },
    data:()=>({

    }),
}
</script>
